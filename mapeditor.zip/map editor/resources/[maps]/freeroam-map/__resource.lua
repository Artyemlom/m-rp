resource_type 'map' { gameTypes = { freeroam = true } }

map 'map.lua'
