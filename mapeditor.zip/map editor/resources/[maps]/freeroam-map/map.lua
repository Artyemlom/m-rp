spawnpoint 'ig_brucie' { -238.511, 954.025, 11.0803 }
spawnpoint 'ig_bulgarin' { -310.001, 945.603, 14.3728 }

car_generator "polpatriot" { -309.911, 922.181, 14.2549 }
