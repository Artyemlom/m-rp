client_scripts {
    'client/initial.lua',
    'client/leavehandler.lua',
    'client/activationhandler.lua',
    'client/hostservice.lua',
    'client/sessionstarter.lua'
}

server_script 'server/host_lock.lua'

export 'serviceHostStuff'
